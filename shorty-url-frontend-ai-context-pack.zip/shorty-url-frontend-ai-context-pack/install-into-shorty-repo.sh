#!/usr/bin/env bash
set -euo pipefail

if [ "${1:-}" = "" ]; then
  echo "Usage: ./install-into-shorty-repo.sh /absolute/path/to/Shorty-URL-Frontend"
  exit 1
fi

TARGET_DIR="$1"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/repo-files"

if [ ! -d "$TARGET_DIR" ]; then
  echo "Target directory does not exist: $TARGET_DIR"
  exit 1
fi

echo "Copying AI context files into: $TARGET_DIR"
mkdir -p "$TARGET_DIR/.github" "$TARGET_DIR/docs/ai"
cp "$SOURCE_DIR/CLAUDE.md" "$TARGET_DIR/CLAUDE.md"
cp "$SOURCE_DIR/AGENTS.md" "$TARGET_DIR/AGENTS.md"
cp "$SOURCE_DIR/llms.txt" "$TARGET_DIR/llms.txt"
cp "$SOURCE_DIR/.github/copilot-instructions.md" "$TARGET_DIR/.github/copilot-instructions.md"
cp "$SOURCE_DIR/docs/ai/"*.md "$TARGET_DIR/docs/ai/"
cp "$SOURCE_DIR/docs/ai/repo-context.json" "$TARGET_DIR/docs/ai/repo-context.json"

echo
echo "Done."
echo "Recommended next commands:"
echo "  cd "$TARGET_DIR""
echo "  git status"
