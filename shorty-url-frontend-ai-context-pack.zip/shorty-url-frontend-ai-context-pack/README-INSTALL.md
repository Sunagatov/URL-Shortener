# Shorty URL Frontend — AI Context Pack

This pack contains repo files you can copy into the root of `Sunagatov/Shorty-URL-Frontend`.

## Fastest way

1. Download and unzip this pack.
2. Open a terminal in the unzipped folder.
3. Run:

```bash
chmod +x install-into-shorty-repo.sh
./install-into-shorty-repo.sh /absolute/path/to/Shorty-URL-Frontend
```

## Manual way

Copy the contents of `repo-files/` into the root of your repository, preserving paths.

## What you get

- `CLAUDE.md`
- `AGENTS.md`
- `llms.txt`
- `.github/copilot-instructions.md`
- `docs/ai/repo-overview.md`
- `docs/ai/api-surface.md`
- `docs/ai/truth-sources-and-known-drifts.md`
- `docs/ai/token-efficient-workflow.md`
- `docs/ai/repo-context.json`
- `docs/ai/task-prompts.md`
